#!/bin/sh
#
# Shellscript for the examplefile of EPCMetrics

# Java-CLASSPATH
CLASSPATH=$CLASSPATH:../lib/xercesImpl.jar:../epctools.jar

# Inputfile or directory
INPUTFILE="example_epcmodel.epml"
# Outputfile or directory
OUTPUTFILE="."
# Configurationfile
CONFIGFILE="../metrics_configuration.xml"

# build up the parameterstring for java
OPTIONS="-i $INPUTFILE -o $OUTPUTFILE -c $CONFIGFILE"


java -cp $CLASSPATH \
	de.ulpz.ebus.epc.metrics.BatchMetricCalculator $OPTIONS